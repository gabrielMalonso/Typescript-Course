# Leitor de Aulas

Aplicação React com Vinext/Vite para ler os materiais do currículo pessoal em Markdown e recortes PDF. Preserva as rotas da fase inicial com TypeScript e aceita a estrutura flexível dos capítulos futuros.

## Versão hospedada

O leitor está publicado com acesso privado em:

<https://leitor-typescript-gabriel.gabrielm-alonso.chatgpt.site>

A reformulação curricular e o capítulo 10 foram publicados em 09/09/2026 na versão 31, no projeto existente e com acesso privado preservado. A URL acima é a retornada pelo Sites na confirmação.

## Como usar

```bash
cd leitor
npm install
npm run dev
```

Configure os identificadores e segredos conforme o [guia do leitor PDF](src/pdf/README.md). Abra o endereço local com callback cadastrado no WorkOS.

## Rotas

- `/` — home, progresso e índice
- `/pad/` — TypeScript Pad, com login opcional e rascunho sincronizado
- `/pad/connect` — confirmação autenticada de um aparelho Android
- `/pad/dispositivos` — revogação dos aparelhos conectados ao Pad
- `/ler/:caminho` — leitura (ex.: `/ler/00-preparacao-do-ambiente/aula/01-teoria`)

## Escalabilidade

Novos capítulos em pastas `NN-nome/` entram no índice via `import.meta.glob`, conforme as seções permitidas em `src/content/catalog.ts`:

- Histórico: README, aula, extras, listas de exercícios e enunciado da prova.
- Guias por curadoria: README, notas.md opcional e pratica/atividades.md. O capítulo 10 usa esses três documentos e seis recortes PDF; o 11 usa guia, três aulas por assunto em `02-aulas-do-curso/`, prática e três recortes PDF (nove páginas: 253–255, 256–260 e 261). O índice apresenta 01. Leituras do livro, 02. Aulas do curso e 03. Prática. O caminho antigo de notas redireciona ao guia.
- Formatos anteriores continuam reconhecidos: aula, prática numerada 01–03, debugging/LeetCode/lab, perguntas do checkpoint, resumo/erros comuns/revisitar e referências. Isso não torna essas etapas obrigatórias.

Respostas, soluções, correções, resultados e gabaritos ficam fora do catálogo. Variações de nomes/seções precisam ser conferidas na geração de cada capítulo. Avaliações de bloco em `avaliacoes/` e capstones em `projetos/` deverão ser integrados quando seus primeiros enunciados forem criados; essas pastas ainda não têm materiais novos.

Arquivos sensíveis (`.context/`, `correcoes.md`, `resultado.md`, gabaritos) ficam fora do catálogo. Os 14 caminhos substituídos do capítulo 10 redirecionam ao novo README sem recolocar o material antigo no índice.

Atualização em 10/09/2026: piloto por curadoria e leitor PDF noturno publicados na versão 32, com acesso privado e publicação confirmada. A versão 31 acima descreve o histórico anterior.

## TypeScript Pad

Home e sidebar abrem o Pad como aplicação independente no mesmo domínio. O código-fonte
vem do pacote `vendor/typescript-pad-0.2.0.tgz`, gerado pelo projeto `typescript-pad`;
`npm run pad:build` compila esse pacote em `public/pad/` antes de `dev` e `build`.
Não editar o pacote instalado nem manter uma segunda implementação do editor.
Para atualizar: no projeto Pad, executar `npm pack --pack-destination ../Typescript-Course/leitor/vendor`;
no leitor, executar `npm install ./vendor/typescript-pad-VERSAO.tgz` e verificar o build.

O editor salva localmente sem login. Com WorkOS, `convex/pad.ts` sincroniza um rascunho
por proprietário, com revisões e resolução explícita de conflitos. No Android, uma
credencial aleatória é aprovada em `/pad/connect`, guardada com Android Keystore e
limitada ao Pad por 30 dias. Somente seu hash fica no banco; contas diferentes não
podem aprovar aparelhos. A tela de dispositivos permite revogação imediata.

O Worker libera somente o HTML e assets do Pad sem WorkOS; páginas de conta e todo o
curso continuam protegidos. A barreira privada do Sites permanece e pode exigir a
entrada na hospedagem antes de abrir a versão web. O APK funciona sem essa barreira
e sem conexão; usa o navegador somente para aprovar a sincronização.

O código dos exercícios executa em Worker dentro de iframe com origem opaca e rede
bloqueada, separado do login. Não enviar tokens de conta ao executor.

## Progresso

O estado exibido na home fica em `src/content/progress.json`. Alterá-lo somente quando solicitado, com base nas entregas ou no relato correspondente; criar uma aula não significa concluir seu estudo. Não manter um registro documental paralelo de progresso.

## Verificação

Testes: `npm test` (autorização, sincronização e links de páginas). Após mudanças no leitor, executar `npm run typecheck`, `npm run lint` e `npm run build`. Conferir home e rota pertinente, mantendo as rotas existentes. Publicação requer escopo autorizado e deve reutilizar `leitor/.openai/hosting.json`, URL e acesso existentes.

## Leituras PDF

Colocar somente o recorte selecionado em `NN-capitulo/leituras/nome.pdf`, acompanhado de `nome.json`. O catálogo exige `title`, `book`, `edition`, `section`, `printedStart`, `sourcePdfStart` e `pageCount`; as páginas são numeradas a partir de 1. Cada recorte é contínuo. Para intervalos distintos, criar recortes separados.

Para apontar uma página, use `[p. 14 — abrir enunciado](../leituras/clrs-1.2.pdf#page=4)` nas atividades: 14 é a página impressa; 4 é a posição dentro do recorte 11–14. O leitor preserva o fragmento e espera as páginas anteriores terem altura definida antes de rolar. Fragmentos inválidos abrem a primeira página. A pinça não refaz esse salto. Não usar a posição do PDF completo em `#page=`.

A partir do capítulo 10, README aparece como “Guia de estudo”, com retorno a ele nos rodapés de notas/prática. Seções numeradas de nível 2 do guia usam `#etapa-N`; atividades numeradas de nível 3 em `pratica/atividades.md` usam `#atividade-N`. Outros títulos usam minúsculas, sem acentos/pontuação, com hífens entre palavras (ex.: `#memoria`). Links a notas devem incluir o fragmento e um retorno à etapa correspondente. Os caminhos antigos permanecem válidos.

O link relativo `[Título · páginas](leituras/nome.pdf)` no README abre um cartão de leitura. PDF e metadados entram automaticamente no índice. O EmbedPDF é carregado somente ao abrir uma leitura, com ferramentas nativas no rodapé e header compartilhado. Anotações são sincronizadas pelo Convex e separadas por versão do arquivo; o PDF original permanece intacto.

Após adicionar ou substituir PDFs, execute `npm run readings:sync` para regenerar o cadastro e atualizar o backend, depois valide e publique o site. `dev` e `build` também regeneram o cadastro local, mas não modificam o backend. Configuração do login e arquitetura: [leitor PDF](src/pdf/README.md).

Incluir apenas os recortes autorizados para o acesso do site; o livro completo permanece fora do repositório. No piloto, páginas impressas 11–14 correspondem às posições 32–35 do PDF enviado. O recorte inclui os limites completos das páginas, e o guia delimita a seção estudada.


Atualização posterior em 10/09/2026: interface de leitura simplificada publicada na versão 33, com confirmação `succeeded` e acesso privado preservado. Somente índice e alternância do modo noturno na barra; páginas em rolagem contínua.


Zoom interno do PDF publicado em 10/09/2026 na versão 34, com estado `succeeded`: pinça amplia o documento e mantém a barra fixa. Validação em tablet físico ainda não realizada.


O leitor Markdown e o PDF compartilham `ReaderToolbar` e `ThemeToggle`. O PDF usa o tema persistido por `ThemeProvider`, mantendo a barra mínima sem cabeçalho editorial. Leituras do capítulo 10: 1.2 (11–14), introdução de 2.1 (16–18), 2.2 em dois recortes (23–25 e 27–29), 3.1 (43–49) e 3.2 (55–57). Total: 23 páginas originais; os limites pedagógicos dentro das páginas continuam no guia.


Atualização em 10/09/2026, versão 35 publicada (`succeeded`): barra e tema compartilhados entre Markdown/PDF; cinco recortes CLRS do capítulo 10 disponíveis (20 páginas). Protótipo aprovado por Gabriel; estudo e domínio não concluídos.

Pastas numeradas do capítulo 11 usam caminhos físicos novos; o catálogo normaliza os endereços para manter URLs e IDs de anotações dos PDFs. O registro de leituras aceita ambas as convenções, sem mudar o hash ou criar outro histórico. Livro vem primeiro como regra geral; o guia intercala aula e prática.
