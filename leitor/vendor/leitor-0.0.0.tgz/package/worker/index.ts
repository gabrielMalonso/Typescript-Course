import {
  DEFAULT_DEVICE_SIZES,
  DEFAULT_IMAGE_SIZES,
  handleImageOptimization,
} from 'vinext/server/image-optimization'
import handler from 'vinext/server/app-router-entry'
import { withStudyAccess, type AuthEnv } from './study-auth'

interface Env extends AuthEnv {
  ASSETS: { fetch(request: Request): Promise<Response> }
  IMAGES: {
    input(stream: ReadableStream): {
      transform(options: Record<string, unknown>): {
        output(options: {
          format: string
          quality: number
        }): Promise<{ response(): Response }>
      }
    }
  }
}

interface ExecutionContext {
  waitUntil(promise: Promise<unknown>): void
  passThroughOnException(): void
}

const worker = {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    return withStudyAccess(request, env, async () => {
      const url = new URL(request.url)
      if (url.pathname === '/pad') return Response.redirect(url.origin + '/pad/' + url.search, 308)
      if (url.pathname === '/pad/') {
        const response = await env.ASSETS.fetch(new Request(new URL('/pad/index.html', request.url), request))
        return new Response(response.body, { status: response.status, headers: { ...Object.fromEntries(response.headers), 'Cache-Control': 'no-cache' } })
      }

      if (url.pathname === '/_vinext/image') {
        const allowedWidths = [...DEFAULT_DEVICE_SIZES, ...DEFAULT_IMAGE_SIZES]
        return handleImageOptimization(
          request,
          {
            fetchAsset: (assetPath) =>
              env.ASSETS.fetch(new Request(new URL(assetPath, request.url))),
            transformImage: async (body, { width, format, quality }) => {
              const options = width > 0 ? { width } : {}
              const result = await env.IMAGES.input(body).transform(options).output({
                format,
                quality,
              })
              return result.response()
            },
          },
          allowedWidths,
        )
      }

      if (env.ASSETS && (request.method === 'GET' || request.method === 'HEAD')) {
        const asset = await env.ASSETS.fetch(request)
        if (asset.status !== 404) return asset
      }
      return handler.fetch(request, env, ctx)
    })
  },
}

export default worker
